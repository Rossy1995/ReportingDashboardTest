﻿namespace ReportingDashboard.Controllers
{
    internal class GoogleAuthenticatorViewModel
    {
        public string SecretKey { get; set; }
        public string BarcodeUrl { get; set; }
    }
}